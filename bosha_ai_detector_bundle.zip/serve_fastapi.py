from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
from PIL import Image
import numpy as np
import io, cv2, tempfile

app = FastAPI(title="Bosha AI Detector API")

def run_inference_placeholder(image: Image.Image):
    prob_synthetic = float(np.random.rand())
    prob_real = 1.0 - prob_synthetic
    label = "synthetic" if prob_synthetic > 0.5 else "real"
    return {
        "label": label,
        "confidence": round(max(prob_real, prob_synthetic), 4),
        "probs": {"real": prob_real, "synthetic": prob_synthetic}
    }

@app.post("/detect/image")
async def detect_image(file: UploadFile = File(...)):
    contents = await file.read()
    image = Image.open(io.BytesIO(contents)).convert("RGB")
    return JSONResponse(run_inference_placeholder(image))

@app.post("/detect/video")
async def detect_video(file: UploadFile = File(...)):
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".mp4")
    tmp.write(await file.read())
    tmp.close()

    cap = cv2.VideoCapture(tmp.name)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    step = max(1, frame_count // 5)

    synthetic_scores, real_scores = [], []
    idx = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if idx % step == 0:
            img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            r = run_inference_placeholder(img)
            synthetic_scores.append(r["probs"]["synthetic"])
            real_scores.append(r["probs"]["real"])
        idx += 1
    cap.release()

    if not synthetic_scores:
        return JSONResponse({"error": "No frames processed"})

    prob_syn = float(np.mean(synthetic_scores))
    prob_real = float(np.mean(real_scores))
    return JSONResponse({
        "label": "synthetic" if prob_syn > prob_real else "real",
        "confidence": round(max(prob_syn, prob_real), 4),
        "probs": {"real": prob_real, "synthetic": prob_syn}
    })
